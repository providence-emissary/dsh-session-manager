#!/usr/bin/env node
// install.mjs — dsh-session-manager 独立安装器
//
// 目标：把本插件装进一个 DSH profile，全程不触碰其他插件的依赖版本。
//
// 做什么：
//   1. package.json：dependencies 里把本插件设为 file: 引用（其它条目原样保留），
//      dsh.profile.bundles 追加 "dsh-session-manager"（去重）；
//   2. cordis.patch.yml：末尾追加 - insert 条目（已存在则跳过）；
//   3. node_modules/dsh-session-manager/：tarball 内容原位展开（fzstd 已打进包内，
//      无外部依赖，不需要跑包管理器）；
//   4. pnpm-lock.yaml：不做修改——lockfile 描述的是「包管理器安装」的树，本插件
//      不经包管理器，没有对应 store 记录。下次其他插件升级跑 pnpm 时，pnpm 会对
//      file: 引用做一次重解析（产物与本地展开一致，无害）。
//
// 用法（两种入口等价）：
//   node install.mjs [profile 目录]        # 在解开的插件包目录里运行
//   node install.mjs <tarball> [profile]   # 直接装 .tgz
//
// 缺省 profile：~/.dsh/profiles/desktop；DSH_HOME 环境变量可重定向（与宿主同口径）。

import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync, copyFileSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const here = dirname(fileURLToPath(import.meta.url))

const PLUGIN_NAME = 'dsh-session-manager'
const BUNDLE_ENTRY = 'dsh-session-manager'
const PATCH_MARKER = 'name: dsh-session-manager'

function fail(msg) {
  console.error('✗ ' + msg)
  process.exit(1)
}

// ── 参数解析 ─────────────────────────────────────────────────────────────────

const args = process.argv.slice(2)
const dshHome = process.env.DSH_HOME || join(homedir(), '.dsh')
const defaultProfile = join(dshHome, 'profiles', 'desktop')

let pkgSource      // 解开后的包目录（含 package.json）
let sourceTgz      // 源 tarball（tgz 模式才有；目录模式现场打包）
let tmpExtracted   // 从 tgz 解开的临时目录（收尾删除）
let profileDir

const first = args[0]
if (first && first.endsWith('.tgz')) {
  sourceTgz = resolve(first)
  if (!existsSync(sourceTgz)) fail('tarball 不存在：' + sourceTgz)
  tmpExtracted = join(tmpdir(), 'dsm-install-' + Date.now())
  mkdirSync(tmpExtracted, { recursive: true })
  try {
    execFileSync('tar', ['-xzf', sourceTgz, '-C', tmpExtracted], { stdio: 'pipe' })
  } catch (err) {
    fail('解压 tarball 失败（' + err.message + '）')
  }
  const inner = readdirSync(tmpExtracted)
  const pkgDir = inner.includes('package') ? join(tmpExtracted, 'package') : tmpExtracted
  if (!existsSync(join(pkgDir, 'package.json'))) fail('tarball 里找不到 package.json')
  pkgSource = pkgDir
  profileDir = resolve(args[1] || defaultProfile)
} else {
  pkgSource = here
  if (!existsSync(join(pkgSource, 'package.json'))) fail('当前目录不是插件包目录（缺 package.json）')
  profileDir = resolve(first || defaultProfile)
}

console.log('插件来源：' + pkgSource)
console.log('目标 profile：' + profileDir)

if (!existsSync(profileDir)) fail('profile 目录不存在（先启动一次 DSH 让它生成）：' + profileDir)
for (const f of ['package.json', 'cordis.patch.yml']) {
  if (!existsSync(join(profileDir, f))) fail('profile 目录缺少 ' + f + '（不是 desktop profile？）')
}

const version = pkgVersion()

// ── 步骤 1：package.json（只动本插件相关字段）───────────────────────────────

const pkgPath = join(profileDir, 'package.json')
let profilePkg
try {
  profilePkg = JSON.parse(readFileSync(pkgPath, 'utf8'))
} catch (err) {
  fail('package.json 不是合法 JSON：' + err.message)
}
if (!profilePkg.dependencies || typeof profilePkg.dependencies !== 'object') profilePkg.dependencies = {}
if (!profilePkg.dsh || typeof profilePkg.dsh !== 'object') profilePkg.dsh = {}
if (!profilePkg.dsh.profile || typeof profilePkg.dsh.profile !== 'object') profilePkg.dsh.profile = {}
if (!Array.isArray(profilePkg.dsh.profile.bundles)) profilePkg.dsh.profile.bundles = []

// 依赖形态：file: 引用指向 profile 的 vendor 目录（正斜杠路径，pnpm/Windows 都稳定）
const vendorDir = join(profileDir, 'vendor')
const vendoredTgz = join(vendorDir, PLUGIN_NAME + '-' + version + '.tgz')
const relRef = 'file:./vendor/' + basename(vendoredTgz)

let pkgChanged = false
if (profilePkg.dependencies[PLUGIN_NAME] !== relRef) {
  profilePkg.dependencies[PLUGIN_NAME] = relRef
  pkgChanged = true
}
if (!profilePkg.dsh.profile.bundles.includes(BUNDLE_ENTRY)) {
  profilePkg.dsh.profile.bundles.push(BUNDLE_ENTRY)
  pkgChanged = true
}
if (pkgChanged) {
  writeFileSync(pkgPath, JSON.stringify(profilePkg, null, 2) + '\n')
  console.log('✓ package.json：dependencies + dsh.profile.bundles 已更新')
} else {
  console.log('• package.json：已是最新，跳过')
}

// tarball → vendor/（file: 引用的实体；重装覆盖）。源：tgz 模式用原 tarball，
// 目录模式找同目录 pack 产物，都没有就现场打一个。
mkdirSync(vendorDir, { recursive: true })
if (!sourceTgz) {
  const packed = join(here, PLUGIN_NAME + '-' + version + '.tgz')
  sourceTgz = existsSync(packed) ? packed : packTgz(pkgSource, vendoredTgz)
}
copyFileSync(sourceTgz, vendoredTgz)
console.log('✓ vendor/' + basename(vendoredTgz))

// ── 步骤 2：cordis.patch.yml 追加 insert 条目 ────────────────────────────────

const patchPath = join(profileDir, 'cordis.patch.yml')
const patchText = readFileSync(patchPath, 'utf8')
if (!patchText.includes(PATCH_MARKER)) {
  const block = [
    '',
    '# ── ' + PLUGIN_NAME + '（由 install.mjs 追加）──────',
    '- insert:',
    '    - id: session-manager',
    '      name: ' + PLUGIN_NAME,
    '',
  ].join('\n')
  writeFileSync(patchPath, patchText.replace(/\s*$/, '') + '\n' + block)
  console.log('✓ cordis.patch.yml：insert 条目已追加')
} else {
  console.log('• cordis.patch.yml：已有条目，跳过')
}

// ── 步骤 3：node_modules 原位展开 ────────────────────────────────────────────

const destDir = join(profileDir, 'node_modules', PLUGIN_NAME)
rmSync(destDir, { recursive: true, force: true })
mkdirSync(dirname(destDir), { recursive: true })
cpSync(pkgSource, destDir, { recursive: true })
console.log('✓ node_modules/' + PLUGIN_NAME + '/ 已展开（' + countFiles(destDir) + ' 个文件）')

// ── 收尾 ─────────────────────────────────────────────────────────────────────

if (tmpExtracted) rmSync(tmpExtracted, { recursive: true, force: true })
console.log('')
console.log('✅ 安装完成。重启 DSH 后，右侧栏「🗂 会话管理」即可用。')
console.log('   本安装器不运行包管理器、不修改其他插件的任何版本。')

// ── 工具函数（主流程在前，定义提升在后）─────────────────────────────────────

function pkgVersion() {
  try {
    return JSON.parse(readFileSync(join(pkgSource, 'package.json'), 'utf8')).version || '0.0.0'
  } catch {
    return '0.0.0'
  }
}

function countFiles(dir) {
  let n = 0
  const walk = (d) => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      if (e.isDirectory()) walk(join(d, e.name))
      else n++
    }
  }
  walk(dir)
  return n
}

/** 纯 Node 调 tar 打包（目录 → pnpm 可读的 tgz）；返回输出路径。 */
function packTgz(srcDir, outPath) {
  try {
    execFileSync('tar', ['-czf', outPath, '-C', dirname(srcDir), basename(srcDir)], { stdio: 'pipe' })
  } catch (err) {
    fail('打包 tarball 失败（' + err.message + '）')
  }
  return outPath
}
